<?php
	$server = "localhost";
	$username = "root";
	$password = "root";
	$database = "proves";

	$con = new mysqli($server, $username, $password, $database);